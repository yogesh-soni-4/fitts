import 'package:fitts/widgets/child_appbar.dart';
import 'package:fitts/widgets/stats.dart';
import 'package:fitts/widgets/parent_appbar.dart';
import 'package:fitts/widgets/dates.dart';
import 'package:fitts/widgets/graph.dart';
import 'package:fitts/widgets/info.dart' hide Stats;
import 'package:fitts/widgets/steps.dart';
import 'package:fitts/widgets/bottom_navigation.dart';
import 'package:flutter/material.dart';

class ChildPage extends StatefulWidget {
  const ChildPage({Key? key}) : super(key: key);

  @override
  State<ChildPage> createState() => _ChildPageState();
}

class _ChildPageState extends State<ChildPage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: ChildMainAppBar(appBar: AppBar()),
        body: Column(
          children: [
            Dates(),
            Steps(),
            Graph(),
            Info(),
            Divider(height: 30),
            Stats(),
            SizedBox(height: 15),
            // BottomNavigation(),
            // SizedBox(height: 45),
          ],
        ),
      ),
    );
  }
}
