import 'package:fitts/pages/form.dart';
import 'package:fitts/widgets/form_button.dart';
import 'package:fitts/widgets/stats.dart';
import 'package:fitts/widgets/parent_appbar.dart';
import 'package:fitts/widgets/dates.dart';
import 'package:fitts/widgets/graph.dart';
import 'package:fitts/widgets/info.dart' hide Stats;
import 'package:fitts/widgets/steps.dart';
import 'package:fitts/widgets/bottom_navigation.dart';
import 'package:flutter/material.dart';

class ParentPage extends StatefulWidget {
  const ParentPage({Key? key}) : super(key: key);

  @override
  State<ParentPage> createState() => _ParentPageState();
}

class _ParentPageState extends State<ParentPage> {
  List<DateBox> dateBoxes = [];
  void activeDate() {
    DateTime date = DateTime.now().subtract(const Duration(days: 3));

    for (int i = 0; i < 6; i++) {
      // if (i == 3) {}
      dateBoxes.add(DateBox(
        date: date,
      ));
      date = date.add(const Duration(days: 1));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey.shade50,
        appBar: ParentMainAppBar(appBar: AppBar()),
        body: Column(
          children: [
            Dates(),
            Steps(),
            Graph(),
            Info(),
            Divider(height: 20),
            Stats(),
            // BottomNavigation(),
            // SizedBox(height: 45),
            SizedBox(height: 7),
            FormButton(),
            SizedBox(height: 15),
          ],
        ),
      ),
    );
  }
}
