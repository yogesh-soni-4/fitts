import 'package:fitts/widgets/stats.dart';
import 'package:fitts/widgets/parent_appbar.dart';
import 'package:fitts/widgets/dates.dart';
import 'package:fitts/widgets/graph.dart';
import 'package:fitts/widgets/info.dart' hide Stats;
import 'package:fitts/widgets/steps.dart';
import 'package:fitts/widgets/bottom_navigation.dart';
import 'package:flutter/material.dart';

class DetailsPage extends StatelessWidget {
  const DetailsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: ParentMainAppBar(appBar: AppBar()),
        body: Column(
          children: [
            Dates(),
            Steps(),
            Graph(),
            Info(),
            Divider(height: 30),
            Stats(),
            SizedBox(height: 30),
            BottomNavigation(),
            // SizedBox(height: 45),
          ],
        ),
      ),
    );
  }
}
