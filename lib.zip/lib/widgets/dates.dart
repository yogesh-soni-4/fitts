import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitts/helpers.dart';
import 'package:fitts/models/health_trackers.dart';
import 'package:flutter/material.dart';

class Dates extends StatefulWidget {
   Dates({Key? key}) : super(key: key);
  final  List<DateBox> dateBoxes = [];
  Function activeDate();


  @override
  State<Dates> createState() => _DatesState();
}

class _DatesState extends State<Dates> {
  @override
  Widget build(BuildContext context) {
    List<DateBox> dateBoxes = [];

    // DateTime date = DateTime.parse('2021-11-08');
    DateTime date = DateTime.now().subtract(const Duration(days: 3));

    for (int i = 0; i < 6; i++) {
      // if (i == 3) {}
      dateBoxes.add(DateBox(
        date: date,
      ));
      date = date.add(const Duration(days: 1));
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: dateBoxes,
      ),
    );
  }
}

class DateBox extends StatefulWidget {
  // final bool active;
  final DateTime date;

  DateBox({
    Key? key,
    // this.active,

    required this.date,
  }) : super(key: key);

  @override
  State<DateBox> createState() => _DateBoxState();
}

class _DateBoxState extends State<DateBox> {
  int day = DateTime.now().weekday;
  Future<void> fetchItems(DateTime date) async {
    await FirebaseFirestore.instance
        .collection("Report")
        .doc(date.toString().substring(0, 11))
        .snapshots()
        .listen((event) {
      setState(() {
        data["Weight"] = event.get("Weight");
        data["BP"] = event.get("BP");
        data["Ex"] = event.get("Excercise_duration");
        // print(documentData);
      });
    });
  }

  @override
  void initState() {
    super.initState();
    fetchItems(widget.date);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Container(
        width: 50,
        height: 72,
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
        decoration: BoxDecoration(
          gradient: widget.date.weekday == day
              ? const LinearGradient(colors: [
                  Color(0xff92e2ff),
                  Color(0xff1ebdf8),
                ], begin: Alignment.topCenter)
              : null,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xffe1e1e1),
          ),
        ),
        child: DefaultTextStyle.merge(
          style: widget.date.weekday == day
              ? const TextStyle(color: Colors.white)
              : null,
          child: Column(
            children: [
              Text(
                daysOfWeek[widget.date.weekday]!,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
              // const SizedBox(height: 0),
              Text(widget.date.day.toString().padLeft(2, '0'),
                  style: const TextStyle(
                    fontSize: 27,
                    fontWeight: FontWeight.w500,
                  )),
            ],
          ),
        ),
      ),
      onTap: () {
        setState(() {
          fetchItems(widget.date);
          selected_date = widget.date;
          // widget.active = true;
          day = widget.date.weekday;
        });
      },
    );
  }
}
